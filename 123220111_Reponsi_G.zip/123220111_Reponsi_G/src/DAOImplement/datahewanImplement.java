/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOImplement;
import java.util.*;
import crud.model.*;

/**
 *
 * @author PC PRAKTIKUM
 */
public interface datahewanImplement {
    public void insertData(datahewan p);
    public void updateData(datahewan p);
    public void deleteData(int id);
    public List<datahewan> getAll();
    
}
