/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOdatahewan;
import java.sql.*;
import java.util.*;
import koneksi.connector;
import crud.model.*;
import DAOImplement.datahewanImplement;
/**
 *
 * @author PC PRAKTIKUM
 */
public class datahewanDAO implements datahewanImplement{
    Connection connection;
    final String select = "SELECT * FROM titip_hewan";
    final String insert = "INSERT INTO titip_hewan(nama_pemilik, nama_hewan, jenis_hewan, nomor_telepon, durasi_titip, total_biaya) VALUES(?, ?, ?, ?, ?, ?)";
    final String update = "UPDATE titip_hewan SET nama_pemilik=?, nama_hewan=?, jenis_hewan=?, nomor_telepon=?, durasi_titip=?, total_biaya=? WHERE id=?";
    final String delete = "DELETE FROM titip_hewan where id=?";
    public datahewanDAO(){
        connection=connector.connection();

        public List <datahewan> getAll(){
            List<datahewan> dh = null;
            try{
                dh = new ArrayList<datahewan>();
                Statement st= connection.createStatement();
                ResultSet rs = st.executeQuery(select);
                while(rs.next()){
                    datahewan hewan = new datahewan();
                    hewan.setId(rs.getInt("id"));
                    hewan.setNama_pemilik(rs.getString("nama_pemilik"));
                    hewan.setNama_hewan(rs.getString("nama_hewan"));
                    hewan.setJenis_hewan(rs.getString("jenis_hewan"));
                    hewan.setNomor_telepon(rs.getString("nomor_telepon"));
                    hewan.setDurasi_titip(rs.getInt("durasi_titip"));
                    hewan.setTotal_biaya(rs.getInt("total_biaya"));
                    dh.add(hewan);
                } 
                        }catch(Exception e){
                        System.out.println(e.getMessage());
               
            }
        return dh;
            
        }

    @Override
    public void insertData(datahewan p) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, p.getNama_pemilik());
            statement.setString(2, p.getNama_hewan());
            statement.setString(3, p.getJenis_hewan());
            statement.setString(4, p.getNomor_telepon());
            statement.setInt(5, p.getDurasi_titip());
            statement.setInt(6, p.getTotal_biaya());
            
        } catch(SQLException e){
            e.printStackTrace();
        } finally{
            try{
                statement.close();
            } catch (Exception e){
                e.getStackTrace();
            }
        }
        
    }

    @Override
    public void updateData(datahewan p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteData(int id) {
       PreparedStatement statement = null;
       
      try{
          statement = connection.prepareStatement(delete);
          statement.setInt(1, id);
          statement.executeUpdate();
      } catch(SQLException e){
          e.printStackTrace();
      } finally{
          try{
              statement.close();
          } catch(Exception e){
              e.getStackTrace();
          }
      }
    }
    }
