/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud.controller;
import java.util.*;
import crud.model.*;
import DAOdatahewan.*;
import DAOImplement.*;
import crud.view.MainView;
/**
 *
 * @author PC PRAKTIKUM
 */
public class datahewanController {
    MainView frame;
    datahewanImplement impldatahewan;
    List<datahewan> dh;
    
    public datahewanController(MainView frame){
        this.frame = frame;
        impldatahewan = new datahewanDAO();
        dh = impldatahewan.getAll();
    }
    
    public void isitabel(){
        dh = impldatahewan.getAll();
        modeldatahewan mp = new modeldatahewan(dh);
        
    }
}
